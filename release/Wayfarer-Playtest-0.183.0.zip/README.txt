WAYFARER - PLAYTEST BUILD 0.183.0

Build 0.183.0 presents shop stock as graphical item cards with category icons, quality, local price, quantity, and concise item details. Companions no longer carry a constant E · TALK prompt; pending personal stories get a specific prompt.

GRAPHICAL SHOP STOCK & COMPANION PROMPTS · 0.183.0
Shop inventories use individual cards with item category icons, quality grades when relevant, shelf count, local price, and short item notes. Companion cards no longer show a constant E · TALK label overhead; a ready or offered personal story uses its own contextual label.

UNDISCOVERED QUEST MAP MARKERS · 0.182.0
The world chart includes the active quest's next destination even before you discover it, labeled UNMAPPED · QUEST LEAD and framed in gold. It reveals no neighboring unknown areas or route lines. The quest tracker button opens the chart to the target.

NPC PASS-THROUGH & SHOP STAFFING · 0.181.0
Walking through a resident no longer stops the player. Each active shop has a keeper standing inside on a walkable floor tile; missing keepers are generated for that settlement and keep the shop's own catalog available.

NPC & SHOP INTERACTION · 0.180.0
Double-click a nearby person on the map to talk without moving to the E key. Double-clicking a tile without a nearby NPC retains its no-turn inspection behavior. In a shop interior, speaking to the shopkeeper opens their specific shop catalog immediately, using that shop's current stock and pricing.


SERVICE & QUEST WAYFINDING · 0.179.0
Gold interaction labels appear near service doors and nearby NPCs. A shop label leads to the shopkeeper conversation and its clearly named shop panel; Guild and Quest Office labels identify their boards. The Guild conversation names its companion roster as hiring and recruitment, while individual applicants show explicit hire and invite actions. The sidebar marks the active quest's next destination and opens the discovered-world map directly; the map centers a known destination and frames it with a gold QUEST TARGET label. The local map marks Quest Office, Guild, shop, and inn doors with Q, G, S, and I.


THE RAINWARD COMPACT & THE QUIET BELL · 0.99.0
Adds ten independently playable guild stories across two linked files. The Rainward Compact includes The River’s Old Name, The Silt-Crowned Regent, False Gates at Low Water, Grain Beyond the Floodline, and A Line for the Living. Its jobs survey flood routes, hunt a named basilisk, clear Red Sash collectors, deliver grain into Brindlewood’s market, and document a public flood line. The Quiet Bell includes A Bell with No Tower, The Bellfounder’s Shade, Cut the Pike-Captain’s Ropes, Bronze for a Clear Note, and The Note That Drew the Drake. Its jobs survey signal routes, hunt a named wraith, clear Hollow Pike deserters, deliver copper ore to Stonebridge, and hunt Riftwing, a named drake.
All twenty story postings now have independent briefings and objectives; none requires a previous chapter. Accepted jobs use the existing single-commission slot, pay normal fame and guild standing, and leave the main campaign stage unchanged. Completed reports persist in saves and enter the shared world history and rumor network. The two new supply jobs use existing market delivery credit, so grain and ore enter the towns’ real trade stocks.
DUNGEON RESCUE & PARTY TACTICS · 0.98.0
Guild boards offer repeatable rescue contracts for named couriers, surveyors, historians, healers, guards, guides, and gatherers last seen in discovered dungeons. Each survivor waits at a stable location on a generated depth from 2 through 4; E frees them and their saved escort state follows the active commission across visits and saves. The survivor follows one tile per tick, can receive a field tonic when approached, and must stay within reach at each stair. The job completes only after the survivor and adventurer both reach the dungeon entrance, then pays normal guild rewards and records the rescue in world history and rumors without advancing the main campaign chapter.
Companions now pause their formation-following during nearby fights, pursue foes into usable attack range, select targets based on recent retaliation and danger to wounded allies, and reposition for clear ranged lines. Their morale and accumulated strain affect attack accuracy; badly injured, shaken companions fall back toward the adventurer. Field attacks improve Combat or Magic through practice, and fully broken carried weapons produce a clear warning instead of stopping the party turn.

THE UNCLAIMED CHARTER · 0.97.0
Five new independently available contracts extend the guild story board: Settlements on Paper, The Factor's Second Name, Wagons Without a Witness, The Beacon That Wasn't There, and A Copy for Every Market. Their linked reports follow a phantom shipping charter that invents settlements, tolls, and a harbor beacon. Any posting can be accepted by itself, in any order, from a Quest Office or Adventurers' Guild. It uses existing region-survey, named-hunt, and expedition objectives; normal guild rewards apply. Completed reports persist and spread through the world's history and rumor network without advancing the main campaign chapter.

INDEPENDENT STORY POSTINGS · 0.96.0
The Quest Office and every Adventurers' Guild expose five Unfinished Mile contracts on a separate posting board: The Marker Turned Inland, A Ledger With No King, The Bell That Counted No Miles, Three Empty Toll Houses, and A Road Worth Keeping. Each briefing gives its own context; no posting requires another. Take one contract at a time, complete it for normal fame and guild standing, and turn it in to record the story. Optional stories leave the main campaign chapter untouched; their results enter shared world history and the rumor system.

DUNGEON CHAMBERS, TRAPS & BOSSES · 0.95.0
Generated floors target 10–14 connected chambers; new rooms extend the established floor plan while preserving legacy room, cache, and trap coordinates. Eight physical and arcane trap mechanisms populate a target of 3–6 locations per floor. Floors divisible by four gain one of six milestone guardians—a regenerative troll, basilisk, dragon, wraith, armored skeleton, or ogre—with its established species tactics and a marked boss silhouette. Crown Revenants remain on floors divisible by five. Defeating a guardian grants bonus coin and a guaranteed relic selected for the floor depth. Existing saves retain cleared bosses and dungeon progress; previously visited floors receive missing new chamber residents and uncleared milestone guardians.

DUNGEON TREASURES · 0.94.0
Adds 24 new valuables to the chest pool, for 72 distinct treasures total. New early finds broaden the variety in shallow caches, while late-floor antiques require depths 9, 11, 13, or 15. The deepest rewards include the Crown of the Unwritten Emperor, Heart of Dusk, and the First Light engine, each with a four-figure face value.

DUNGEON TREASURES · 0.93.0
Adds 28 new finds to the catalog, for 48 named dungeon valuables total. The new finds begin on the first floor; each deeper tier adds rarer antiques, sacred objects, royal heirlooms, dragon relics, and legendary artifacts. Each piece has its own face value and locally adjusted resale appraisal.

DUNGEON TREASURES · 0.92.0
Twenty named valuables range from the Jade idol of the Sun Court to the Unmaking Eye. Chest contents favor finds suited to the current dungeon depth; every cache includes a relic and coin, with occasional field medicine. Treasures occupy cargo space and can be sold at locally adjusted appraisals.

EVERYDAY ITEMS · 0.91.0
Everyday items have saved quantities and can appear in seeded owned containers or provisioner stocks. Spoons and forks remain in the pack after a meal; a linen napkin is used up with a ration. New field tea, antiseptic wash, and whetstones have direct nourishment, wound-care, and weapon-repair effects.

OWNED FURNISHINGS · 0.90.0
Storage props receive seeded contents suited to the furnishing and building. Press E beside a container to inspect it; (Steal) takes a chosen item, costs a tick, and uses the existing witness, justice, and NPC memory simulation. Taken items stay removed when the building is revisited.

FURNISHING VARIETY · 0.89.0
More than 40 new small furnishings receive distinct canvas art and are selected from a pool matching the building's purpose. Decorative accents stay walk-through and avoid solid furniture, doors, stairs, and partitions. Their placement is stable for each saved run.

PARTITIONED INTERIORS · 0.88.0
Generated room dividers block movement like interior walls, include an open passage, and appear only where a usable door-to-stair route remains. Layouts that do not fit retain their open floor plan. Generation is stable for each building in a saved run.

INTERIOR GENERATION · 0.87.0
Interior layouts fit each building's footprint and preserve an open route from the door to the stairs. Their furnishing variation stays stable for a saved run. Existing saves generate these layouts as buildings are visited.
DAILY TASK PROGRESS · 0.86.0
Resident task records save arrival, elapsed activity ticks, and completion. Work tasks generally need three ticks, meals and market visits two, social visits two or three, and rest or quiet recovery three or four. Existing saves initialize progress when residents next advance their routines.
ENDLESS PROCEDURAL FRONTIER · 0.77.0
Sector coordinates now remain exact beyond the range where ordinary JavaScript numbers can distinguish adjacent places. Climate and terrain remain continuous between neighboring sectors, and the world chart and route simulation understand the extended coordinates.

DISTINCT REGIONS · 0.78.0
Landmark occurrence and placement, wilderness enemy count and positions, and the palette of smaller generated towns now vary by sector. A region keeps the same results when revisited. Major city grids and terrain generation remain stable.

SETTLEMENT GENERATION · 0.79.0
Generated farming communities, mining towns, ports, market towns, and roadside inns now use one of four deterministic mirrored plans. Buildings, entrances, roads, resident work locations, and specialty ground features stay aligned. Revisiting a settlement restores the same plan. Existing saves keep the previous layout for each visited settlement; new plans are saved.

WILDERNESS ROUTES · 0.80.0
North-south and east-west trails bend through each wilderness sector but enter neighboring sectors at their shared centered crossings. The routes connect near the center, and generated landmarks are placed clear of the trails.

START PLAYING
1. Create a folder and extract the contents of `Wayfarer-Playtest-0.82.0.zip` into it.
2. Open index.html in a current desktop browser such as Microsoft Edge or Google Chrome.
3. The game runs locally and does not need an installer or an internet connection.
4. Create an adventurer before beginning. The game autosaves this run in the browser profile.

CHARACTER CREATION AND ROGUELIKE RUNS
Choose a name, pronouns, homeland, calling, starting weapon, hairstyle, complexion, hair color, and cloak color. Spend six starting skill points among Combat, Armor, Magic, and Fieldcraft. Callings provide different starting supplies. Skills continue improving through use.
If your character dies, the run ends permanently. The active character save is removed, a short run record is kept in this browser, and the next adventurer must be created from the beginning.

BOW AND ARROW COMBAT
Start with 12 arrows. The Ash shortbow reaches six tiles and the Yew longbow reaches eight. Ready either bow with Q, then use Shift + A to select a target, body region, and Quick shot or Full-draw shot. Arrows need a clear path; walls, terrain, and creatures in the way block a shot. Provisioners and outfitters sell 12-arrow bundles. Ammunition is saved with your run.

CONTROLS
WASD / Arrow keys  Move one tile (one game tick)
E                  Enter buildings, speak, open chests, study dungeon seals, inspect traps or recent traces, use stairs/cache, or butcher
Space              Quick attack a nearby foe or wild animal
Shift + A          Choose a target, attack technique, and body region; bows can shoot at range
F                  Forage mature, healthy plants in season
Q                  Cycle melee weapons, bows, and arcane foci
H                  Use a field tonic
B                  Apply a bandage
M                  Open or close the discovered-world map; its local-trail button shows the current area's terrain and buildings
Shift + D          Attempt to disarm a nearby dungeon trap
Pack [use] buttons  Use rations, antitoxin, salve, smoke pots, ward charms, tempering oil, and repair rolls
Road Companions panel  Equip allies, transfer arrows, treat wounds, and train them in safe towns


DUNGEON PUZZLES
Each dungeon depth selects one of eight distinct sealed mechanisms, such as brass tumblers, counterweight sluices, resonant bars, root lattices, blind dials, oath gates, ash-brand locks, and tideglass irises. Approach a marked seal and press E to study it. Choose a carried iron key, test the mechanism's named skill, cast its listed spell if your Magic skill has unlocked it, or batter the lock with your selected weapon. Each chosen method advances one tick. Skill attempts can fail and leave fresh tool marks; forcing a lock spends weapon durability and can break the weapon. Every successful method leaves a different persistent mark, opens the same passage, records its history, and reveals a niche with coin, a regional good, and another iron key. New puzzle records initialize as you visit dungeon floors in an existing run.

DUNGEON WATER AND AIR
Dungeon rooms have persistent water and air conditions. Seepage and underground streams feed low chambers; water drains and flows through connected passages according to elevation. Drafts and vents bring in fresher air, while smoke spreads through open routes and clears faster where ventilation is stronger. Sealed puzzle doors leak only a little; cave-ins stop the flow. Rising water can submerge a corridor sill and change the route, while the adventurer, stairs, and unopened caches remain reachable. Room-entry reports describe water, smoke, and the draft ahead. Ember magic can add smoke; stale air, smoke, and deep water burden breathing. The body panel gives a brief diagnosis, and conditions continue changing while you are away.

DUNGEON TRACES
Dungeon floors preserve fading boot prints, claw tracks, disturbed dust, drag marks, scraps, and abandoned tools. Patrols leave tracks as they move; wounded enemies can leave a limping or dragged trail. Fights, sprung traps, searches, and forced passages leave debris and scuffs. When a monster group abandons its lair, its tracks show where it moved and may leave tools behind; returning monsters leave fresh traces. Room-entry reports point out recent signs, and E beside a mark reads its age, source, and direction. New traces fade over several in-game days, and return reports summarize significant movement while you were away. These records initialize on older saves.

COMMUNITY ILLNESS
Three broad seasonal illnesses can move through settlements: winter cough, marsh fever, and redgut. Season, crowding, local water and food stress, and access to care shape how often they spread. Clinics and apothecaries draw on local herb supplies to replenish remedies; an outbreak can empty their shelves. Care helps residents recover sooner, while sicker workers rest through missed shifts, reducing local income and goods. Ask residents about health or news, or read the clinic report while browsing remedies, to hear what is spreading and how much treatment stock remains. The simulation runs in the background with no extra disease-management screen.

LOCAL JUSTICE
Theft and violence can open a local case when a resident reports the offense or witnesses see it. Each settlement applies its own customs: stricter courts assess higher fines and are more likely to issue warrants, while close-knit communities are more willing to forgive. Fines reflect the offense, injury or stolen value, and your standing with the people involved. Speak with the local watch to pay the fine and restitution or make a one-time appeal. An injured resident or theft victim may accept restitution or forgive the offense; their personality and relationship with you affect the outcome. Local cases, warrants, and resolutions persist with your run, and NPCs who know what happened can mention it naturally.

CHANGING CONTROL OF ROADS
Road regions have persistent control records for local rulers, guard patrols, and the Red Sash Company, Hollow Pike Band, and Ash-Crown Marauders. Patrols strengthen guard control; ruler levies assert local toll charters; bandit raids can seize a road and its camp. Control shifts through the days and is saved with the run. The place header reports who holds the road, its current danger, and the toll. Find the small roadside camp near the track and press E to inspect its banner, patrol and raid record, latest change, toll, and route risk. Defeating a bandit weakens that gang's hold; a takeover can create a matching Guild clearance job.

Road tolls are charged when crossing into a controlled wilderness route. Bandit-held roads demand higher extortion, contested roads charge a smaller disputed toll, and guards reduce danger. Caravans account for tolls when choosing profitable shipments, pay local tolls as they travel, and can be delayed at checkpoints or lose goods to the faction holding an unsafe road. Their ledger reports tolls paid, delays, and cargo losses. Road control and history persist in new saves; older character saves continue with local control generated as each region is visited.

MONSTER FIELD GUIDE
Trolls recover health and knit tissue between turns unless active burn trauma interrupts them. Dragons use scaled armor and attack from six tiles with cinder breath that leaves a lingering burn; their talons rake at close range. Ogres hurl heavy fieldstones from two to five tiles and swing crushing mauls when cornered. Basilisks alternate a telegraphed petrifying gaze with neurotoxic bites; mineral interference reduces modeled mobility for several ticks. Wraiths attack through the veil with a vitality-draining touch and restore part of the strength they steal. Each new monster can leave a unique trophy when defeated.

ENEMY MOTIVES AND BATTLE REPORTS
Enemies notice nearby attacks; members of the same band or kind can hear a fight and join it. Foes split pressure across the player and companions, with a modest preference for an already injured target. When an ally is badly hurt, a nearby foe may turn on the player or companion threatening them. Melee groups take clear steps around terrain and can spread to opposite sides of a target; ranged foes sidestep for clear shots or move back into their effective distance. POSITION, FLANK, and COORDINATION lines explain these choices. Badly hurt bandits may break away or surrender when their group is outnumbered or has lost allies. Beasts and lesser monsters can also flee when badly hurt. Escaped foes award no kill credit or spoils. Surrendered foes stop fighting and show an S marker; Shift+A lets you choose whether to attack a surrendered foe.

BANDIT FACTIONS AND CLEARANCE JOBS
The Red Sash Company patrols the Northroad, Sunmead, and Willowfen approaches with poisoned stiletto ambushes. The Hollow Pike Band holds Oldwatch, the Broken March, and parts of the Northroad with disciplined pike formations. The Ash-Crown Marauders roam Suncleft, Saltmere, the ruins, and the highlands; firebrands throw cinder flasks while zealots press in with branded blades.
The Quest Office adds three authored gang-clearance chapters after the monster campaign: XXV targets the Red Sash Company, XXVI clears the Hollow Pike Band, and XXVII scatters the Ash-Crown Marauders. Each job requires four marked members defeated across two faction territories. Only members tagged to the assigned gang count. After the story, repeatable contracts periodically commission a gang clearance with seeded faction, routes, and tactics.

COMPANIONS, MOTIVATION, AND TRAINING
Guild halls have four unique applicants: a trail scout who wants to chart unknown roads, a shield hand who values a reliable company, a hedge adept seeking field evidence, and a field medic devoted to bringing people home. Only the shield hand accepts a signing fee; the others must be invited for reasons that fit their ambitions. Trust, fame, current work, the player's magic skill, and a wounded party can affect whether an invitation succeeds.
The Road Companions panel manages up to three living party members. Equip weapons and fitted armor from the shared gear locker, transfer arrows to a bow user, and repair companion weapons or armor with repair rolls. Companions use ranged bows, close weapons, or ranged aether attacks, gain Combat, Armor, and Magic through use, and retain their own skill practice. Pay for focused training in any safe town. Fieldcraft-trained companions improve harvest yields and meat freshness when they assist with butchering. Tonics and bandages can treat their injuries; treatment, equipment changes, and training each advance one tick.
Companions have individual histories, motives, equipment, physiology, and permanent life records. Enemies can target and kill them. A companion can part ways alive in a settlement and return to their original guild with their own equipment; after a short wait, you may invite them again. If killed, they are removed from the active party and cannot be revived or recruited again; their death remains in the memorial record.
Companions build individual bonds with one another as well as with you. The Road Companions panel shows morale, accumulated strain, trust, and each member's closest party bond; a companion can also describe how they feel about another traveling member. Shared danger can strengthen party ties while raising strain. A companion's death causes grief among survivors, and the party remembers severe neglect of food, rest, company, or injury care. Personality shapes reactions when you attack a surrendered foe. Recovery improves morale; prolonged low trust or morale can make a companion leave alive and return to their guild with their gear. These relationships and standing persist in existing saves.

SCRIPTED QUESTS AND GUILD FAME
Start as a D-Rank adventurer in Brindlewood. The Quest Office offers 29 authored commission stages, beginning with cutpurses and waystone surveys, then following a long campaign through the Hollow Pike and Ash-Crown bands, trolls, fey, a lost caravan, royal revenants, and the rebuilding of public roads. Chapters IX–XX continue the story through the Salt Ledger, Blackwater Bell, Briar Saint, Frost Cairn, Lantern Granaries, Kings’ Writ, Rook’s Last Bargain, Standard Bearer, Long Green Mile, Saltglass Marshal, Bell and Seed, and the Last Marshal. The final four chapters add a cinder-breathing dragon, boulder-throwing ogre, venomous petrifying basilisk, and life-draining wraith; chapters XXV–XXVII then commission clearances of the three named bandit groups. After the authored arc, repeatable guild work generates seeded monster hunts and gang clearances. Return to any Quest Office or city guild hall to claim rewards.
Complete 3 guild jobs for C-Rank, 8 for B-Rank, 16 for A-Rank, and 30 for S-Rank. Fame also grows through deeds and discoveries.

WORLD EVENTS AND CONNECTED GUILD JOBS
Guild notice boards can post work from current world reports: worker meal shortages create grain-relief deliveries; delayed or robbed caravans create road recovery jobs; active bandit groups create faction-specific clearance jobs; and living monster sightings create named hunts. Each posting identifies the affected settlement or route and sets its objective from the reported problem. Completing the work resolves that event in the world ledger and awards normal guild pay, fame, and rank progress without advancing the 29-chapter story sequence.

PERSISTENT EVENT HISTORY IN NPC CONVERSATIONS
The world keeps a short, persistent history of why important events happened and how they ended. Companions who shared a fallen ally’s last journey, nearby witnesses, locals affected by a shortage, and guild-connected travelers can bring those events up in conversation. Ask about news, safety, work, or the road to hear a relevant account, including the cause and any resolution. Guild clearances also leave a record that affected roads were made safer.

SEASONAL SETTLEMENT RESILIENCE
Every settlement tracks stored grain, water, pasture forage, and cattle, sheep, and poultry. Spring and summer weather shapes crop condition; autumn records a harvest and winter demand draws down local stores. Water recharge, pasture growth, herd births, and losses change with local conditions. Short reserves reduce food restocking, raise food prices, and limit worker earning capacity; caravan shipments and player food deliveries replenish settlement stores. A poor harvest or sustained shortage can create a Guild grain-relief job. Check the resilience line in a trade ledger or ask residents about local news and work. These records persist in existing saves.

SHOPS AND CITY MARKETS
Each town and city has specialty shops for travel provisions, remedies, armor, or outfitting. Buy field tonics, bandages, venom vials, trail food, and armor fitted to individual body regions. Armor quality now changes tensile strength, resistance, and durability. Local market conditions and item quality both change prices between settlements. Specialty stock replenishes each in-game day. Armorers add bronze lamellar, brigandine, scale, moonsteel, and warded leather, all with separate resistance, tensile-strength, and durability values. Branna can forge bound-bone armor from four harvested bones. New pack items include field rations, antitoxin, wound salve, smoke pots, ward charms, tempering oil, and armor repair rolls; each use advances one tick. Rations restore a little vitality, nourish you, and ease pain, standard antitoxin clears active toxins while worn antitoxin weakens them; salve reduces pain and shock, smoke blocks nearby foes for one enemy turn (two for masterwork), a ward charm reduces the next arcane hit, oil adds damage to the next physical strike, and a repair roll restores durability to the armor worn on the selected region.

NEW FINDABLE AND TRADEABLE ITEMS
Trade factors now buy and sell iron bars, copper ingots, valley berry wine, dye cakes, rag paper, beeswax, coastal amber, mountain gemstones, and moonsteel fragments alongside the existing food, ore, cloth, tools, and craft goods. Dungeon caches can contain valuables from those markets. Trolls, drakes, ogres, basilisks, and wraiths leave distinct tradeable trophies; faction bandits may carry their gang's tally seal, watch insignia, or royal seal. Collect these goods into cargo and sell them to traders. Local production, demand, and remaining stock change both prices and availability, so a route can pay better than selling at the first town. Provisioners, outfitters, armorers, and apothecaries also carry a small rotating selection of these goods.

BUILDINGS AND LOCAL INDUSTRY
Brindlewood adds the Common Mill and Oak & Hide Workshop. Inns, guild halls, and exchanges are larger, and Stonebridge and Saltmere add glassworks and ropeworks. Mining towns gain a charcoal kiln and smeltery, farming communities gain a creamery, ports gain a sailmaker's loft, market towns gain a caravan yard, and roadside inns gain a stable and cart yard.

SETTLEMENT WORK AND SHORTAGES
Workers buy local materials, use them to produce trade goods, and sell some output into local demand. Their input costs and sales change their income, market stock, and prices. A missing material costs a shift's pay and sends the worker to the market during an automatic errand; a shortage of food or cash can leave them hungry and pull them away from work. Workers spend part of their income on meals. Shop ledgers show local production, inputs, sales, meals, income, and shortages; ask a worker about their work to hear their current situation. NPC schedules run on their own.
DAILY NPC ROUTINES
NPC days now use eight time periods: dawn sleep, breakfast, morning work, a midday meal, afternoon work, local errands, evening visits, and night sleep. Job-specific schedules add details for city clerks, guild staff, merchants, herbalists, farmers, miners, harbor crews, and inn workers. Residents tend to work near home, households sometimes share breakfast and lunch, and weekly market visits fall in the afternoon. Existing residents and traveling encounters follow the same eight-period clock. Each action still advances one tick.
NPC VARIETY
Generated residents draw from a wider set of regional given names and family names, 14 additional personality profiles, and expanded jobs for city wards, farms, mines, ports, markets, inns, guild halls, and travelers. The new profiles have their own conversational manner, sample remarks, traits, and ambitions; routine variations reflect work such as floodgate tending, mine rescue, fish auctions, ration packing, and public fountain care.
HOUSEHOLD CARE AND RECOVERY
When a resident has an exposed bleeding wound or an open wound that needs cleaning, a caring household member can use a bandage from the local market stock to dress it. First aid can slow external bleeding and reduce contamination; it does not erase serious injuries or replace time and medical treatment. The patient and caregiver remember the help, and the existing town work ledger records residents helped and bandages used. Ask about health or family to hear the personal account. Care happens automatically and existing saves remain compatible.
RESIDENT LIFE CHANGES
Residents now age with the seasonal year, retire after a working lifetime, and form new households as local friendships deepen. Shopkeepers can train apprentices; apprentices learn through their shifts, improve the quality of shop stock, and may inherit the business when the owner retires or dies. Workers whose shifts remain unpaid can change trades or move to a more prosperous settlement, reducing production where they leave and adding new workers where they arrive. Ask residents about their work or check a city's existing work ledger for retirements, apprenticeships, shop succession, household changes, and migration. Schedules, trade experience, age, and household ties persist in existing saves.
HOUSING PRESSURE
Households track their residents, home, room capacity, rent, and arrears. The trade ledger shows occupied and vacant homes, spare beds, crowded households, rent due, unpaid balances, and recent arrivals. New arrivals are placed in homes with room when possible; otherwise the town records the extra pressure. Weekly rent comes from household purses. Crowding and missed rent can increase stress, illness risk, and missed work; pressure also draws market traffic and shifts staple and building-material prices. When builders choose a new site, pressured neighborhoods are favored. Ask the Homes & rent topic to hear the neighborhood report or the resident’s own household account. Older saves initialize housing records as settlements are visited.
LOCAL GOVERNMENT AND POLICY
Each town or city has a ruler or council with a persistent treasury and policy record. Local taxes and market rules change shop prices and trade flow. Regional toll rates shape caravan costs. Security priorities affect patrols, theft, and route safety. Public works priorities guide municipal crews as they repair roads, wells, bridges, drains, lights, and walls, spending from public funds. Residents can explain current policies and recent decisions; the trade ledger reports taxes, tolls, morale, safety, treasury, and repair spending. Councils review policies as food, crime, infrastructure, and funds change. Government state persists with the run and initializes automatically for settlements in older saves.

DISTINCT NEIGHBORHOODS
Every settlement is divided into named neighborhoods with different housing, trades, local wealth, resident jobs, and services. Mining settlements have pithead, ore exchange, miner, and smelter wards; farming towns have farmsteads, village greens, and mill rows; ports have fish quays, salt markets, and ropewalks. Larger cities distinguish civic, market, craft, and crowded river wards. District names and wealth appear as you travel, and residents describe local work and available services in conversation. Trade factors and specialist shops use modest neighborhood price shifts for local surpluses and demand. Resident routines, work material costs, and earnings respond to their district. Older saves derive neighborhoods from the existing town layouts and resident records.
CITY EXPANSION
Procedural major cities span 100 by 78 tiles and now contain 92 buildings, with two added homes and ten small covered storefronts filling the central market lane. Each generated city has 132 to 156 individually named residents representing a population of 25,000 to 74,999. Five city profiles keep their palettes, landmarks, district names, industries, production, and market needs distinct: canal exchange, foundry capital, collegiate court, caravan crossroads, and Stonebridge’s authored bridge confluence. Stonebridge spans 68 by 52 tiles and now has 29 buildings, 25 named residents, and a represented population of 25,600. New West Arch, Bridgewright, and Quay Garden homes and the Farbank Cargo Counter connect the lower wards to the existing footpath grid.
AUTHORED PEOPLE AND PROFESSIONAL SKILLS
Regional name banks include distinct city and countryside names, and generated work draws from larger occupation lists matched to farms, mines, ports, markets, guilds, inns, and city wards. Each resident receives a professional specialty and a task-specific description for work shifts. Their persistent evening routine reflects a personal pastime and a small contribution to the neighborhood; ask about likes and pastimes or read the conversation context to learn more.
Residents produce goods during scheduled shifts, and recipes use local market stock. Poultry keepers gather eggs; mushroom growers bring baskets to market. Both goods can be bought, sold, and eaten by workers, and seasonal food supply affects their availability. Farmers, fishers, miners, shepherds, and gatherers supply other raw materials. Millers grind grain into flour; bakers and dairy workers make bread and cheese; tanners, weavers, rope makers, potters, glassworkers, smiths, smelters, vintners, dyers, papermakers, gem cutters, and chandlers turn stored materials into finished goods. Importing scarce inputs can restart a stalled workshop. The daily trade ledger reports local production, sales, material use, and shortages. Saved residents gain the new personal details as their routines advance.
QUALITY AND CONVERSATIONS
Items can be Worn, Standard, Fine, Superior, or Masterwork. Higher grade fitted armor gains durability, tensile strength, and resistance; higher grade tonics, dressings, poisons, remedies, and field tools improve their effects. Quality changes shop prices, and each merchant's daily stock keeps its quality through saves. The pack lists the grades you carry; the best grade is used first. Older saves load with their existing items at Standard quality.
Speak with every living resident, generated traveler, and party companion. Type any question or choose from quick topics covering identity, family, work, hopes, beliefs, relationships, health, needs, likes, memories, adventurer reputation, wildlife, settlement shortages and services, local customs, faction threats, trade, travel, and safety. A Trust & trouble prompt asks what each resident has witnessed and remembers about your actions. Replies draw on the person's profile, personality, current location and surroundings, nearby activity, household and social ties, needs, memories, and your reputation when relevant. People remember recent exchanges across saves, acknowledge when they do not know something, and respond differently as trust grows. Each question advances one game tick. NPCs who witness theft remember the event, react according to their relationship with you, and may spread the story.
RUMORS, SOURCES, AND RELIABILITY
Important events now leave dated rumor records. Accounts remember named witnesses, what the source claimed, the report's confidence, and how many days passed before a listener heard it. Residents can pass news through trusted relationships; Guild dispatches carry reports along connected roads; real caravans can carry a few local stories between markets. NPCs identify whether they witnessed an event, heard it from a neighbor, received a Guild dispatch, or met a traveling caravan. A short reliability label and percentage distinguishes strong firsthand accounts from uncertain fragments. Different residents may hear different versions and can explain where their accounts disagree. Rumor records persist in saves; existing characters migrate their event history into the new system.
HOMES AND PRIVATE CHESTS
Brindlewood has six occupied, furnished homes plus two staffed workshops, including new miller and tanner households. Stonebridge and Saltmere Port have added residential rows, and generated farming, mining, port, and market towns have more homes with routines and household ties. Every house has furnished ground and upper floors on the same world view, with its rooms formed by wall blocks and an open doorway.

Press E beside a private chest to open it. Each item has a (Steal) choice; opening the chest and taking an item each advance one tick. Contents are generated for the household and persist in your save. A resident who sees you steal remembers it; witnesses lose trust in you, the guild record and fame fall, and local rumors can carry the event.

CARAVAN SUPPLY
Scheduled caravans buy goods where regional supply is strong and carry them along known roads to settlements that pay more. Departures reduce stock at origin markets; deliveries raise stock at destination markets, so buy and sell quotes move with the shelves. Caravans take one day per map leg and can be delayed by rough weather or robbed on dangerous roads. The trade screen shows active routes, expected arrivals, recent deliveries, delays, and losses. In-flight cargo and market notices persist with the run.

TRAVEL AND DUNGEONS
Follow authored roads between towns and biomes, or leave a map edge to discover a new procedurally generated region. Roads can bring traders, couriers, pilgrims, and other travelers. Each settlement has its own guild, shops, prices, and residents. Inns offer a bed and travel supplies; bulk trade and horse-and-cart cargo upgrades support longer journeys.
The Sunken Barrow lies in the Broken March. Procedural wilderness sectors and mining towns can also contain dungeons. Generated floors contain branching routes, monsters, caches, and deeper stairs. Monster groups keep saved lairs and patrol ranges across nearby chambers; rival groups compete for space and shared forage. Intruders, loud fights, depleted forage, and population pressure can drive a group to relocate, and patrols respond to noise. Chambers now have visible purpose-built kitchens, barracks, workshops, shrines, and storehouses. Search a fixture with E to recover one-time supplies and a clue tied to nearby groups, patrols, old rulers, or food stores. Resting guards can wake when you approach or disturb the barracks; furnishings block movement and clear projectile paths. Searches, clues, and territory records persist by floor. Defeated foes stay gone until disturbed lairs draw replacements back over time. Floor traps now keep a history of triggers, safe bypasses, disarms, and resets by nearby inhabitants. Trap plates show whether they are armed, sprung, disarmed, skirted, or freshly reset; press E nearby to inspect the marks and Shift+D to attempt a Fieldcraft disarm, with a failed attempt able to fire the mechanism. On return, the dungeon report summarizes trap resets alongside territory shifts, population changes, empty caches, cave-ins, faded echoes, returning monsters, and the depth population. High structural stress can collapse a corridor; cave-ins preserve access to the stairs and every unopened cache. Existing saves initialize room searches and trap histories as each floor is visited.

WILDERNESS RISK ZONES
Wilderness sectors have seeded risk levels shaped by their biome. Dangerous ranges carry larger populations of dangerous wildlife, especially gray wolves, cougars, wolverines, and bears; wolf packs may hunt together, while elevated ranges have less concentrated predator sign. You receive a warning when entering a dangerous range, and the place header and ecology panel keep its risk visible. Territorial hunters notice you, close distance, and strike at close range even if you did not start the fight. Their numbers and territories are stored with wildlife and ecosystem records, so earlier saves gain these encounters when you revisit wilderness.
COMBAT, PEOPLE, AND ECOLOGY
Combat tracks anatomy by body region, weapon impact, armor material and wear, injuries, and ongoing physiology in the action report. Bandits, beasts, skeletons, sprites, and trolls use distinct attacks. Each armor piece protects its fitted region and can lose durability.
Residents have jobs, titles, histories, relationships, and persistent lives. Generated settlements and road encounters draw from regional name banks, 24 distinct personality archetypes, occupation pools tailored to local industries, and daily routine templates for city, guild, market, farm, mine, harbor, inn, and travel life. Residents who share a home form persistent households, build mutual bonds, and appear in shared conversation details; generated residents in many settlements share some meals at home. Household members respond strongly to nearby injuries and deaths. Every seventh in-game day, many locals gather at the weekly market; attendance varies with personality and occupation, and market conversations build social ties and memories. Personalities shape voice, sociability, ambitions, and relationships. Residents can be recruited as companions, injured, or killed. The expanding wilderness models regional plants and mushrooms, seasonal growth, habitat, soil, and huntable fauna. Animals can be injured, hunted, and butchered for useful materials.


ECOSYSTEM CYCLES
Plant growth responds to local rain, dry weather, and the season as soil moisture changes. Browsing and trampling reduce forage, while wildlife populations breed when food is plentiful and can decline when it remains scarce. Herds now hold saved territories and move between adjacent habitats when forage, water, prey, crowding, hunting pressure, and seasonal ranges change. Predators can follow thinning prey or range toward livestock and food scraps near settlements. On return, the action report names species that became scarce and explains range changes; nearby residents can discuss the same local wildlife news. These ecosystem records and migration routes persist with the run. Existing saves remain compatible.

INJURY RECOVERY
Each action advances recovery by one tick. Blood loss, open wounds, fractures, infection, pain, nourishment, and rest all shape healing over time. Rations and local hot meals restore nourishment; nourishment is tracked quietly and falls during travel. Use B to bind bleeding or clean and redress an open surface wound. Companion care can do the same. Safe inn rest costs coin, improves recovery, reduces pain and infection, rebuilds blood more quickly, and restocks supplies; serious injuries still need time. The body panel gives a short diagnosis and suggested next step. Detailed wound, tissue, organ, nerve, bone, vessel, and blood-loss information remains in the battle report.

EQUIPMENT CONDITION AND REPAIRS
Weapons and armor keep durability, impact history, lifetime wear, and repair counts across saves. Condition is labeled Pristine, Sound, Scuffed, Worn, Damaged, or Broken. Worn weapons deal less damage; worn armor stops less of each hit. Combat reports state the condition change, the reason for wear, and the change to strike power or protection. A material failure names what gave way: split steel fittings, cracked staves, parted chain links, torn backing, and other material-specific failures. The Pack and Road Companions panel show current condition and the latest wear or repair reason.
Visit Branna at Ash & Anvil and choose Repair current weapon to restore the weapon selected with Q; she also repairs the equipped armor region selected in the armor panel. A repair roll restores up to 45 durability to selected equipped armor or a companion’s current weapon or armor. Repair events remain in each item’s history, including what was fixed and how much durability was restored. Existing saves load with pristine weapons and their saved armor condition intact; condition records then autosave with the run.

SAVES AND SHARING
This build is a self-contained HTML5 browser playtest. Saves live in browser localStorage and stay with that browser profile; they do not travel with this ZIP. Discovered map areas, dangerous wildlife species, seeded range populations, territory, settlement records, and resident lives persist with the run. Resident professional specialties and proficiency, settlement government leaders, tax and toll policies, market rules, security and public works priorities, treasuries, morale, safety, and policy histories; settlement service staffing and supply snapshots, queues, shortage relief, street-crime reports, household membership, usable home capacity, rent payments and arrears, arrival records, building conditions, repair and construction projects, vacant lots, reuse, abandonment, and ruin histories persist with the run. Owned chest contents, stolen items, theft counts, NPC memories, personal pastimes and community duties, rumor records, household first-aid memories and ledgers, witness identities, rumor source and age, relay routes, weapon and armor wear histories, and per-floor dungeon cache, lair, patrol range, shared forage, rival pressure, noise, cave-in, monster population, fixture searches, clues, puzzle attempts, solved methods and visible marks also persist in the run.
This is not a Steam depot build. A desktop wrapper, installer, Steam App ID, depot configuration, Steamworks credentials, and Steam achievements are not included.


















CITY EXPANSION
Procedural major cities cover 132×100 tiles, with connected roads through eastward and southern wards. New districts mix homes with guild dispatch, markets, clinics, armor and travel shops, granaries, watch posts, courts, schools, baths, waterworks, shelters, theaters, and warehouses. Residents follow saved work and neighborhood routines, and shops use the larger city economy.
Stonebridge now covers 88×68 tiles. The east-bank extension adds 16 buildings, named residents with individual histories and routines, and public services for trade, health, food, lodging, education, and safety. The route from Sunmead enters at the new east gate.

TACTICAL COMBAT · 0.76.0
Open the attack menu with Shift+A. Choose a body region, then use a measured strike for better accuracy or a driving strike for higher damage and a greater chance to miss. Accuracy reflects the attacker's relevant skill, injuries and pain, the target's mobility, weapon style, aimed region, and range. Critical hits deepen the wound path; critical or heavy blunt impacts can stagger an enemy and interrupt its next action.
When a hostile is nearby, choose Brace in the same menu to spend one tick preparing for the next incoming hit. A brace reduces damage after armor and ward protection, but its effect is lower against arrows and magic. The action report records the chance, roll, result, strike quality, protection, and anatomical consequences.
















